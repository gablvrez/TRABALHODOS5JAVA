package persistencia;

import livros.Livro;
import usuarios.Usuario;
import emprestimos.Emprestimo;
import java.util.List;
import java.io.*;

public class ArquivoJSON extends Persistencia {
    public static void salvarDados(List<Livro> livros, List<Usuario> usuarios, List<Emprestimo> emprestimos) {
        try (PrintWriter writer = new PrintWriter(new File("dados.json"))) {
            // Lógica para salvar dados em arquivo JSON
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }

    public static void carregarDados(List<Livro> livros, List<Usuario> usuarios, List<Emprestimo> emprestimos) {
        try (BufferedReader reader = new BufferedReader(new FileReader("dados.json"))) {
            // Lógica para carregar dados de arquivo JSON
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
