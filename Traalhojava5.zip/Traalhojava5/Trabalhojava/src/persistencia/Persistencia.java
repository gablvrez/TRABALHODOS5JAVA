package persistencia;

import livros.Livro;
import usuarios.Usuario;
import emprestimos.Emprestimo;
import java.util.List;

public class Persistencia {
    public static void salvarDados(List<Livro> livros, List<Usuario> usuarios, List<Emprestimo> emprestimos) {
        // Implementar a lógica de salvamento dos dados em arquivos
    }

    public static void carregarDados(List<Livro> livros, List<Usuario> usuarios, List<Emprestimo> emprestimos) {
        // Implementar a lógica de carregamento dos dados de arquivos
    }
}
