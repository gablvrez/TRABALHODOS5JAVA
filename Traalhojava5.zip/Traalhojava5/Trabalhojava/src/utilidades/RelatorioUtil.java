package utilidades;

import java.util.List;
import emprestimos.Emprestimo;
import usuarios.Usuario;

public class RelatorioUtil {
    public static void gerarRelatorioEmprestimos(List<Emprestimo> emprestimos) {
        // Implementar lógica de geração de relatório de empréstimos
    }

    public static void gerarRelatorioUsuarios(List<Usuario> usuarios) {
        // Implementar lógica de geração de relatório de usuários
    }
}
