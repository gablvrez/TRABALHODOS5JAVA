package utilidades;

import java.text.SimpleDateFormat;
import java.util.Date;

public class DataUtil {
    public static String formatarData(Date data) {
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        return sdf.format(data);
    }

    public static Date parseData(String data) {
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        try {
            return sdf.parse(data);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
}
