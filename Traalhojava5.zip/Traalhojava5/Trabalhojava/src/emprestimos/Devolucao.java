package emprestimos;

import livros.Livro;
import usuarios.Usuario;
import java.util.Date;

public class Devolucao {
    private Livro livro;
    private Usuario usuario;
    private Date dataDevolucao;

    public Devolucao(Livro livro, Usuario usuario, Date dataDevolucao) {
        this.livro = livro;
        this.usuario = usuario;
        this.dataDevolucao = dataDevolucao;
    }

    public Livro getLivro() {
        return livro;
    }

    public Usuario getUsuario() {
        return usuario;
    }

    public Date getDataDevolucao() {
        return dataDevolucao;
    }
}
