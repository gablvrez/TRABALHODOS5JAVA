package emprestimos;

import usuarios.Usuario;

public class Notificacao {
    public static void enviarNotificacao(Usuario usuario, String mensagem) {
        System.out.println("Notificação enviada para " + usuario.getNome() + ": " + mensagem);
    }
}
