package emprestimos;

import usuarios.Usuario;
import java.util.Date;

public class Multa {
    private Usuario usuario;
    private double valor;
    private Date dataPagamento;

    public Multa(Usuario usuario, double valor, Date dataPagamento) {
        this.usuario = usuario;
        this.valor = valor;
        this.dataPagamento = dataPagamento;
    }

    public Usuario getUsuario() {
        return usuario;
    }

    public double getValor() {
        return valor;
    }

    public Date getDataPagamento() {
        return dataPagamento;
    }
}
