package biblioteca;

import livros.Livro;
import usuarios.Usuario;
import emprestimos.Emprestimo;
import persistencia.Persistencia;
import java.util.ArrayList;
import java.util.List;

public class Biblioteca {
    private List<Livro> livros;
    private List<Usuario> usuarios;
    private List<Emprestimo> emprestimos;

    public Biblioteca() {
        livros = new ArrayList<>();
        usuarios = new ArrayList<>();
        emprestimos = new ArrayList<>();
    }

    public void adicionarLivro(Livro livro) {
        livros.add(livro);
    }

    public void adicionarUsuario(Usuario usuario) {
        usuarios.add(usuario);
    }

    public void registrarEmprestimo(Emprestimo emprestimo) {
        emprestimos.add(emprestimo);
    }

    public void salvarDados() {
        Persistencia.salvarDados(livros, usuarios, emprestimos);
    }

    public void carregarDados() {
        Persistencia.carregarDados(livros, usuarios, emprestimos);
    }
}

