package biblioteca;

import livros.Livro;
import java.util.List;

public class Catalogo {
    private List<Livro> livros;

    public Catalogo(List<Livro> livros) {
        this.livros = livros;
    }

    public void adicionarLivro(Livro livro) {
        livros.add(livro);
    }

    public List<Livro> listarLivros() {
        return livros;
    }
}
