package biblioteca;

import emprestimos.Emprestimo;
import usuarios.Usuario;
import livros.Livro;

import java.util.List;

public class Relatorio {
    
    // Relatório de Empréstimos
    public static void gerarRelatorioEmprestimos(List<Emprestimo> emprestimos) {
        System.out.println("Relatório de Empréstimos:");
        for (Emprestimo emprestimo : emprestimos) {
            Livro livro = emprestimo.getLivro();
            Usuario usuario = emprestimo.getUsuario();
            String dataEmprestimo = utilidades.DataUtil.formatarData(emprestimo.getDataEmprestimo());
            String dataDevolucao = utilidades.DataUtil.formatarData(emprestimo.getDataDevolucao());
            
            System.out.println("Livro: " + livro.getTitulo());
            System.out.println("Usuário: " + usuario.getNome());
            System.out.println("Data de Empréstimo: " + dataEmprestimo);
            System.out.println("Data de Devolução: " + dataDevolucao);
            System.out.println("------------------------------");
        }
    }
    
    // Relatório de Usuários
    public static void gerarRelatorioUsuarios(List<Usuario> usuarios) {
        System.out.println("Relatório de Usuários:");
        for (Usuario usuario : usuarios) {
            String endereco = usuario.getEndereco().getRua() + ", " + usuario.getEndereco().getNumero() + " - " + usuario.getEndereco().getCidade() + ", " + usuario.getEndereco().getEstado() + " - " + usuario.getEndereco().getCep();
            String contato = "Telefone: " + usuario.getContato().getTelefone() + ", Email: " + usuario.getContato().getEmail();
            
            System.out.println("Nome: " + usuario.getNome());
            System.out.println("ID: " + usuario.getId());
            System.out.println("Endereço: " + endereco);
            System.out.println("Contato: " + contato);
            System.out.println("------------------------------");
        }
    }
}
