package usuarios;

import livros.Livro;

public class Aluno extends Usuario {
    public Aluno(String nome, String id, Endereco endereco, Contato contato) {
        super(nome, id, endereco, contato);
    }

    @Override
    public void emprestarLivro(Livro livro) {
        livro.emprestar();
        System.out.println("Livro emprestado pelo aluno " + getNome());
    }
}
