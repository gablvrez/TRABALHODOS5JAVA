package usuarios;

import livros.Livro;

public class Bibliotecario extends Funcionario {
    public Bibliotecario(String nome, String id, Endereco endereco, Contato contato) {
        super(nome, id, endereco, contato);
    }

    @Override
    public void emprestarLivro(Livro livro) {
        livro.emprestar();
        System.out.println("Livro emprestado pelo bibliotecário " + getNome());
    }
}
