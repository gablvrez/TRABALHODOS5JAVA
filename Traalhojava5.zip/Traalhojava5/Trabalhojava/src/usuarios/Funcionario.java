package usuarios;

import livros.Livro;

public abstract class Funcionario extends Usuario {
    public Funcionario(String nome, String id, Endereco endereco, Contato contato) {
        super(nome, id, endereco, contato);
    }
}
