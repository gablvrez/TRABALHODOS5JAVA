package usuarios;

import livros.Livro;

public abstract class Usuario {
    private String nome;
    private String id;
    private Endereco endereco;
    private Contato contato;

    public Usuario(String nome, String id, Endereco endereco, Contato contato) {
        this.nome = nome;
        this.id = id;
        this.endereco = endereco;
        this.contato = contato;
    }

    public String getNome() {
        return nome;
    }

    public String getId() {
        return id;
    }

    public Endereco getEndereco() {
        return endereco;
    }

    public Contato getContato() {
        return contato;
    }

    public abstract void emprestarLivro(Livro livro);
}
