import biblioteca.Biblioteca;
import biblioteca.Relatorio;
import livros.Autor;
import livros.Categoria;
import livros.Livro;
import usuarios.*;
import emprestimos.Emprestimo;

import java.util.Arrays;
import java.util.Date;

public class Main {
    public static void main(String[] args) {
        
        Biblioteca biblioteca = new Biblioteca();

        
        Autor autor1 = new Autor("Autor 1");
        Autor autor2 = new Autor("Autor 2");

        
        Categoria categoria1 = new Categoria("Ficção");
        Categoria categoria2 = new Categoria("Ciência");

        
        Livro livro1 = new Livro("Livro 1", Arrays.asList(autor1, autor2), Arrays.asList(categoria1, categoria2));
        Livro livro2 = new Livro("Livro 2", Arrays.asList(autor1), Arrays.asList(categoria1));
        Livro livro3 = new Livro("Livro 3", Arrays.asList(autor2), Arrays.asList(categoria2));

        
        biblioteca.adicionarLivro(livro1);
        biblioteca.adicionarLivro(livro2);
        biblioteca.adicionarLivro(livro3);

        
        Endereco endereco1 = new Endereco("Rua 1", "123", "Cidade 1", "Estado 1", "00000-000");
        Contato contato1 = new Contato("1234-5678", "email1@exemplo.com");

        Endereco endereco2 = new Endereco("Rua 2", "456", "Cidade 2", "Estado 2", "11111-111");
        Contato contato2 = new Contato("8765-4321", "email2@exemplo.com");

        
        Usuario aluno1 = new Aluno("Aluno 1", "1", endereco1, contato1);
        Usuario professor1 = new Professor("Professor 1", "2", endereco2, contato2);

        
        biblioteca.adicionarUsuario(aluno1);
        biblioteca.adicionarUsuario(professor1);

        
        Emprestimo emprestimo1 = new Emprestimo(livro1, aluno1, new Date(), new Date());
        Emprestimo emprestimo2 = new Emprestimo(livro2, professor1, new Date(), new Date());

        biblioteca.registrarEmprestimo(emprestimo1);
        biblioteca.registrarEmprestimo(emprestimo2);

        
        Relatorio.gerarRelatorioEmprestimos(biblioteca.getEmprestimos());
        Relatorio.gerarRelatorioUsuarios(biblioteca.getUsuarios());
    }
}
