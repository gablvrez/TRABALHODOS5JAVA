package livros;

import java.util.List;

public class Livro {
    private String titulo;
    private List<Autor> autores;
    private List<Categoria> categorias;
    private boolean emprestado;

    public Livro(String titulo, List<Autor> autores, List<Categoria> categorias) {
        this.titulo = titulo;
        this.autores = autores;
        this.categorias = categorias;
        this.emprestado = false;
    }

    public String getTitulo() {
        return titulo;
    }

    public List<Autor> getAutores() {
        return autores;
    }

    public List<Categoria> getCategorias() {
        return categorias;
    }

    public boolean isEmprestado() {
        return emprestado;
    }

    public void emprestar() {
        this.emprestado = true;
    }

    public void devolver() {
        this.emprestado = false;
    }
}
