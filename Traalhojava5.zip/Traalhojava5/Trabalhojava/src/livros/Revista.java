package livros;

import java.util.List;

public class Revista extends Livro {
    private String edicao;

    public Revista(String titulo, List<Autor> autores, List<Categoria> categorias, String edicao) {
        super(titulo, autores, categorias);
        this.edicao = edicao;
    }

    public String getEdicao() {
        return edicao;
    }
}
