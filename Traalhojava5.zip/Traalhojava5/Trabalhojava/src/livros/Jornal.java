package livros;

import java.util.List;

public class Jornal extends Livro {
    private String dataPublicacao;

    public Jornal(String titulo, List<Autor> autores, List<Categoria> categorias, String dataPublicacao) {
        super(titulo, autores, categorias);
        this.dataPublicacao = dataPublicacao;
    }

    public String getDataPublicacao() {
        return dataPublicacao;
    }
}
