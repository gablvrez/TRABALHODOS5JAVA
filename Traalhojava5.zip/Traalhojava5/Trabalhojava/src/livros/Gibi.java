package livros;

import java.util.List;

public class Gibi extends Livro {
    private String editora;

    public Gibi(String titulo, List<Autor> autores, List<Categoria> categorias, String editora) {
        super(titulo, autores, categorias);
        this.editora = editora;
    }

    public String getEditora() {
        return editora;
    }
}
