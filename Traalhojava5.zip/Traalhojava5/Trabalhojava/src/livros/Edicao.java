package livros;

public class Edicao {
    private String numeroEdicao;

    public Edicao(String numeroEdicao) {
        this.numeroEdicao = numeroEdicao;
    }

    public String getNumeroEdicao() {
        return numeroEdicao;
    }
}
