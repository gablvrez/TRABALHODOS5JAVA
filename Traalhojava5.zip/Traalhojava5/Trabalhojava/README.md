# Sistema de Biblioteca

## Descrição
Este projeto é um sistema de gerenciamento de biblioteca desenvolvido em Java, utilizando os conceitos de programação orientada a objetos abordados durante o semestre.

## Objetivos
- Gerenciar livros, autores, categorias, usuários e empréstimos.
- Demonstrar o uso de agregação, composição, associação, herança, polimorfismo e tratamento de exceções.
- Persistir dados em arquivos de texto.

## Pacotes e Classes

### Biblioteca
- `Biblioteca`: Classe principal que gerencia o sistema da biblioteca.
- `Catalogo`: Gerencia o catálogo de livros.
- `Relatorio`: Gera relatórios sobre os empréstimos e os livros.

### Livros
- `Livro`: Representa um livro na biblioteca.
- `Autor`: Representa um autor de livros.
- `Categoria`: Representa uma categoria de livros.
- `Revista`: Subclasse de Livro, representa uma revista.
- `Jornal`: Subclasse de Livro, representa um jornal.
- `Gibi`: Subclasse de Livro, representa um gibi.
- `Edicao`: Representa uma edição específica de um livro.

### Usuarios
- `Usuario`: Classe abstrata representando um usuário da biblioteca.
  - `Aluno`: Herda de Usuario, representa um aluno usuário da biblioteca.
  - `Professor`: Herda de Usuario, representa um professor usuário da biblioteca.
  - `Funcionario`: Herda de Usuario, representa um funcionário da biblioteca.
  - `Bibliotecario`: Subclasse de Funcionario, representa um bibliotecário.
- `Endereco`: Representa o endereço dos usuários.
- `Contato`: Representa informações de contato dos usuários.

### Emprestimos
- `Emprestimo`: Gerencia os empréstimos de livros.
- `Reserva`: Gerencia as reservas de livros.
- `Multa`: Gerencia as multas aplicadas por devolução atrasada.
- `Devolucao`: Gerencia a devolução de livros.
- `Notificacao`: Envia notificações para os usuários sobre empréstimos e devoluções.

### Persistencia
- `Persistencia`: Gerencia a leitura e escrita de dados em arquivos.
- `ArquivoTexto`: Implementa persistência de dados em arquivos de texto.
- `ArquivoJSON`: Implementa persistência de dados em arquivos JSON.

### Utilidades
- `DataUtil`: Métodos utilitários para manipulação de datas.
- `RelatorioUtil`: Métodos utilitários para geração de relatórios.
